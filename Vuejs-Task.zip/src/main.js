import Vue from 'vue'
import App from './App.vue'
import pageHeader from './component/tophead/index.vue'
import pageBody from './component/blacktesting/index.vue'
//import Productlist from './component/productsection/index.vue'
import jQuery from 'jquery';
window.$ = window.jQuery = jQuery;
import 'bootstrap' // import bootstrap js files
import 'bootstrap/scss/bootstrap.scss'
import VueResource from 'vue-resource'
//import axios from 'axios'
//Vue.use(axios)
Vue.use(VueResource)


Vue.component('pageheader', pageHeader)
Vue.component('pagebody',pageBody)
//Vue.component('productlist',Productlist)

new Vue({
  el: '#app',
  render: h => h(App)
})
