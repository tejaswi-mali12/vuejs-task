<template>
  <div id="app">
    <pageheader></pageheader>

    <pagebody></pagebody>
  

  </div>
  
  
</template>

<script>

export default {
  name: 'app',
  components: {
  },
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<style lang="scss">

.container{
  width:1366px;
}
@media screen and (max-width:991px) {
  .container{
  width:100%;
  max-width:100%;
}

}
</style>
