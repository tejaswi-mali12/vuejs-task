<template src="./blacktesting.html"></template>
<script src="./blacktesting.js"></script>
<style src="./blacktesting.scss" scoped lang="scss"></style>

