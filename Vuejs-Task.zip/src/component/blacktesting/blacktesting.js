
import axios from 'axios';


export default {
  name: 'blacktesting',
  components: {

  },
  props: [],
  data () {
    return {
    product: [],
    isShowing:false,
    }
  },
  computed: {

  },

   created() {

      //   fetch("weather.json")
      //     .then(response => response.json())
      //     .then(data => (this.weatherDataList = data));
      axios.get("http://localhost:3000/product").then(response => {
        this.product = response.data;
        console.log("array is "+this.product);
      });
      
    
  },

  mounted () {

  },
  methods: {


  }
}


